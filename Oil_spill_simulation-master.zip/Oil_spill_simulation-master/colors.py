from random import randint

ICE_BLUE = (114, 219, 255)
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
PANEL = (112, 109, 108)
PANEL_FRAME = (53, 52, 51)
START_BUTTON = (158, 155, 153)
COLOR_INACTIVE = (0, 0, 0)
COLOR_ACTIVE = (114, 219, 255)
# ICE_BLUE = (randint(0, 255), randint(0, 255), randint(0, 255))
# BLACK = (randint(0, 255), randint(0, 255), randint(0, 255))
# WHITE = (randint(0, 255), randint(0, 255), randint(0, 255))
# PANEL = (randint(0, 255), randint(0, 255), randint(0, 255))
# PANEL_FRAME = (randint(0, 255), randint(0, 255), randint(0, 255))
# START_BUTTON = (randint(0, 255), randint(0, 255), randint(0, 255))
# COLOR_INACTIVE = (randint(0, 255), randint(0, 255), randint(0, 255))
# COLOR_ACTIVE = (randint(0, 255), randint(0, 255), randint(0, 255))
            